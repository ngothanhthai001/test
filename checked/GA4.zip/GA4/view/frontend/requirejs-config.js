var config = {
    map: {
        '*': {
            weltpixel_ga4_gtm: 'WeltPixel_GA4/js/weltpixel_ga4_gtm',
            weltpixel_ga4_persistentLayer: 'WeltPixel_GA4/js/weltpixel_ga4_persistentlayer'
        }
    }
};
