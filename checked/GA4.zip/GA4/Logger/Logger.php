<?php
namespace WeltPixel\GA4\Logger;


class Logger extends \Monolog\Logger
{

}
