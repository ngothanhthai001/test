<?php
namespace WeltPixel\GA4\Logger;


class DebugCollectLogger extends \Monolog\Logger
{

}
