Important notes:
- Extension files for Magento versions 2.4 or higher. 
- Files NOT compatible with Magento version 2.0 - 2.3.x.
- Using different set of files for each Magento version for best performance.
