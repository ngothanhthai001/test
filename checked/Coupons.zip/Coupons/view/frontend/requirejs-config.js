var config = {
    config: {
        mixins: {
            'Magento_SalesRule/js/model/coupon': {
                'Amasty_Coupons/js/model/coupon-mixin': true
            }
        }
    }
};
