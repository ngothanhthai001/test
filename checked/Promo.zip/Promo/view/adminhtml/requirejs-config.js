var config = {
    config: {
        mixins: {
            'Magento_Sales/order/create/scripts': {
                'Amasty_Promo/js/order/create/scripts-mixin': true
            }
        }
    }
};
