<?php

namespace Amasty\Promo\Observer;

class FixCouponsUsageObserver
{

}
