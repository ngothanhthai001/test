<?php

namespace Amasty\Promo\Helper;

/**
 * @deprecated use \Amasty\Promo\Model\Config instead.
 */
class Config extends \Amasty\Promo\Model\Config
{

}
